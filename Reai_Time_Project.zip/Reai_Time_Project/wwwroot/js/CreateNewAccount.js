﻿/*function back() {
    window.open("new.html");
}
//date
var dateDropdown = document.getElementById("date");

for (var i = 1; i <= 31; i++) {
    var option = document.createElement("option");
    option.value = i;
    option.text = i;
    dateDropdown.appendChild(option);
}
// month

var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

var monthDropdown = document.getElementById("month");

for (var i = 0; i < months.length; i++) {
    var option = document.createElement("option");
    option.value = i + 1;
    option.text = months[i];
    monthDropdown.appendChild(option);
}

//year

var monthdropdown = document.getElementById("year");
for (var i = 2026; i >= 1947; i--) {
    var option = document.createElement("option");
    option.value = i;
    option.text = i;
    monthdropdown.appendChild(option);
}

//gender

var genderdropdown = document.getElementById("gender");
var genders = ["male", "female", "others"];
for (i = 0; i < genders.length; i++) {
    var option = document.createElement("option")
    option.value = i + 1;
    option.text = genders[i];
    genderdropdown.appendChild(option);
}

// account created
/* function accountcreated(){
     document.getElementById("submit");
     alert("Connect account created successfuly")
     window.open("new.html");
 }
function Alreadyhaveaccount() {
    alert('redirecting to main page')
    window.open("new.html");
}*/

    function AccountCreated() {
        var ids = ["name", "surname", "date", "month", "year", "gender", "mblnbr", "pwd"];
        var messages = [
            "Enter the Name",
            "Enter the Surname",
            "Please select Date",
            "Please select Month",
            "Please select Year",
            "Please select Gender",
            "Please enter Mobile Number",
            "Please enter Password"
        ];

        for (var i = 0; i < ids.length; i++) {
            var value = document.getElementById(ids[i]).value.trim();

            if (!value) {
                alert(messages[i]);
                return;
            }
        }

        alert("Connect account created successfully");
        window.location.href = "/Login/Login";
    }
