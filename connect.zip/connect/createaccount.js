function back()
{
    window.open("new.html");
}
 //date
            var dateDropdown = document.getElementById("date");

            for (var i = 1; i <= 31; i++) {
                var option = document.createElement("option");
                option.value = i;
                option.text = i;
                dateDropdown.appendChild(option);
            }
// month

        var months = ["Jan","Feb","Mar","Apr","May","Jun",
                    "Jul","Aug","Sep","Oct","Nov","Dec"];

        var monthDropdown = document.getElementById("month");

        for (var i = 0; i < months.length; i++) {
            var option = document.createElement("option");
            option.value = i + 1;
            option.text = months[i];
            monthDropdown.appendChild(option);
        }

//year
   
        var monthdropdown = document.getElementById("year");
        for (var i = 2026; i >= 1947; i--) {
            var option = document.createElement("option");
            option.value = i;
            option.text = i;
            monthdropdown.appendChild(option);
        }

//gender
    
        var genderdropdown = document.getElementById("gender");
        var genders = ["male","female","others"];
        for(i=0; i < genders.length; i++)
    {
        var option = document.createElement("option")
        option.value = i+1;
        option.text = genders[i];
        genderdropdown.appendChild(option);     
    }
    
    