﻿
using System.ComponentModel.DataAnnotations;

namespace Reai_Time_Project.Models
{


    public class LoginModel
    {
        
        [EmailAddress(ErrorMessage = "email is required")]
        public string email { get; set; }

        [Required(ErrorMessage = "Password is required")]
        public string Password { get; set; }
    }
}
