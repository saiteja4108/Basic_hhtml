﻿

using System.ComponentModel.DataAnnotations;

namespace Reai_Time_Project.Models
{

    public class CreateNewAccountModel
    {
        [Required(ErrorMessage = "Name is required")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Surname is required")]
        public string Surname { get; set; }

        [Required(ErrorMessage = "Date of birth is required")]
        public string Day { get; set; }

        [Required(ErrorMessage = "Month is required")]
        public string Month { get; set; }

        [Required(ErrorMessage = "Year is required")]
        public string Year { get; set; }

        [Required(ErrorMessage = "Gender is required")]
        public string Gender { get; set; }

        [Required(ErrorMessage = "Mobile or Email is required")]
        public string Contact { get; set; }

        [Required(ErrorMessage = "Password is required")]
        public string Password { get; set; }
    }
}