﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ViewEngines;
using Reai_Time_Project.Models;
using System.Reflection;

namespace Reai_Time_Project.Controllers
{


    public class Logincontroller : Controller
    {

        public IActionResult Login()
        {
            return View();
        }



        [HttpPost]
        public IActionResult SubmitLogin(LoginModel model)
        {
            if (!ModelState.IsValid)
            {
                return View("Login", model);
            }

            // Example credentials
            if (model.email == "sai@gmail.com" && model.Password == "1234")
            {
                return RedirectToAction("NewLoginPage","Login");
            }
            else
            {
                ModelState.AddModelError("", "The email or password you entered is incorrect.");
                return View("Login", model);
            }
        }
        public IActionResult CreateNewAccount()
        {
            return View();
        }

        [HttpPost]
        public IActionResult CreateNewAccount(CreateNewAccountModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            
            return RedirectToAction("AccountCreated", "Login");
        }
        public IActionResult AccountCreated()
        {
            return View();
        }
        public IActionResult Forgotpassword()
        {
            return View();
        }
        public IActionResult NewLoginPage()
        {
            return View();
        }
    }
}
    


