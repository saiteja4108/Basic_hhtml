  
            function ForgotPassword(){
                var username = document.getElementById('uname').value;
                if(!username)
                {
                alert('User should enter username in the textbox or else Forgot password email sent your inbox' );

                }else
                {
                alert('redirect to forgot page');
                }
        }
             function login(){
                 var username = document.getElementById("uname").value.trim();
                 var password = document.getElementById("pwd").value.trim();
                    if(!username  || !password )
                    {
                    alert('username and password fileds are mandatory');
                    }else{
                    alert('redirect to main page');
                    }
        }
        function CreateNewAcoount(){
                  window.open("createaccount.html")
        }