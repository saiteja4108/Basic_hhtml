﻿using Microsoft.AspNetCore.Mvc;

namespace Reai_Time_Project.Controllers
{
    public class DashboardController : Controller
    {
        public IActionResult Homepage()
        {
            return View();
        }
    }
}
